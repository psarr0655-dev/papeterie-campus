const APP_NAME = "La papeterie du campus";
const body = document.body;

// Petite fonction pour créer un élément HTML
const createEl = el => document.createElement(el);


/* ============================================================
   FONCTIONS QUI EXISTAIENT DÉJÀ
   ============================================================ */

const Header = (title, slogan, logo) => {
    title = String(title).toUpperCase();
    const header = createEl('header');
    header.className = "site-header";
    const div1 = createEl('div');
    div1.className = "header-inner";
    const div2 = createEl('div');
    div2.className = "brand-mark";
    div2.setAttribute("aria-hidden", true);
    div2.textContent = !logo ? `${title.charAt(0)}.` : logo;

    const div3 = createEl('div');
    const p1 = createEl('p');
    p1.className = "brand-name";
    p1.textContent = title;
    const p2 = createEl('p');
    p2.className = "brand-caption";
    p2.textContent = slogan;
    div3.appendChild(p1);
    div3.appendChild(p2);
    div1.appendChild(div2);
    div1.appendChild(div3);
    header.appendChild(div1);
    return header;
}

const Title = (title, subTitle) => {
    const div = createEl('div');
    const h1 = createEl('h1');
    h1.id = "catalog-title";
    h1.textContent = title;
    const p = createEl('p');
    p.className = "intro";
    p.textContent = subTitle;
    div.append(h1, p);
    return div;
}

const Input = (type, lbl) => {
    const label = createEl('label');
    label.className = 'search-label';
    label.setAttribute('for', 'product-search');
    label.textContent = lbl;
    const input = createEl('input');
    input.className = 'search-input';
    input.id = 'product-search';
    input.type = type;
    input.setAttribute('placeholder', 'Cahier, stylo ...');
    const div = createEl('div');
    div.append(label, input);
    return div;
}

const Btn = (text) => {
    const button = createEl('button');
    button.className = 'category-button';
    button.type = 'button';
    button.setAttribute('aria-pressed', true);
    button.textContent = text;
    return button;
}


/* ============================================================
   NOUVELLES FONCTIONS
   ============================================================ */

// Le texte "4 produits"
const ResultCount = (nombre) => {
    const p = createEl('p');
    p.className = 'result-count';
    p.textContent = `${nombre} produits`;
    return p;
}

// CADRE GRIS : l'illustration (le petit cahier dessiné)
// Exemple : Illustration('NOTES', '180 pages')
const Illustration = (titre, info) => {
    const div = createEl('div');
    div.className = 'product-illustration';
    div.setAttribute('aria-hidden', true);

    const cover = createEl('div');
    cover.className = 'product-cover';
    cover.textContent = titre;

    const small = createEl('small');
    small.textContent = info;

    cover.appendChild(small);
    div.appendChild(cover);
    return div;
}

// CADRE VIOLET : le bouton "+ Ajouter"
const AddButton = () => {
    const button = createEl('button');
    button.className = 'add-button';
    button.type = 'button';
    button.textContent = '+ Ajouter';
    button.disabled = true; // sera activé plus tard
    return button;
}

// CADRE ROUGE : une carte produit complète
// Elle utilise Illustration et AddButton
const ProductCard = (produit) => {
    const article = createEl('article');
    article.className = 'product-card';

    const illustration = Illustration(produit.coverTitle, produit.coverInfo);

    const category = createEl('p');
    category.className = 'product-category';
    category.textContent = produit.category;

    const name = createEl('h3');
    name.className = 'product-name';
    name.textContent = produit.name;

    // Le bas de la carte : prix + bouton
    const bottom = createEl('div');
    bottom.className = 'product-bottom';
    const price = createEl('span');
    price.className = 'product-price';
    price.textContent = produit.price;
    bottom.append(price, AddButton());

    article.append(illustration, category, name, bottom);
    return article;
}

// La grille qui contient toutes les cartes
// "produits" est une liste (un tableau) de produits
const ProductGrid = (produits) => {
    const grid = createEl('div');
    grid.className = 'product-grid';

    // On répète ProductCard pour chaque produit de la liste
    produits.forEach(produit => {
        grid.appendChild(ProductCard(produit));
    });

    return grid;
}

// CADRE BLEU : un article dans le panier
// Exemple : CartItem('Lot de 4 stylos', 1, '600 FCFA')
const CartItem = (name, quantity, total) => {
    const li = createEl('li');
    li.className = 'cart-item';

    // Ligne du haut : nom + bouton ×
    const top = createEl('div');
    top.className = 'cart-item-top';
    const itemName = createEl('p');
    itemName.className = 'cart-item-name';
    itemName.textContent = name;
    const remove = createEl('button');
    remove.className = 'remove-button';
    remove.type = 'button';
    remove.setAttribute('aria-label', `Retirer ${name}`);
    remove.textContent = '×';
    remove.disabled = true;
    top.append(itemName, remove);

    // Ligne du bas : quantité + prix de la ligne
    const bottom = createEl('div');
    bottom.className = 'cart-item-bottom';

    const control = createEl('div');
    control.className = 'quantity-control';

    const minus = createEl('button');
    minus.className = 'quantity-button';
    minus.type = 'button';
    minus.setAttribute('aria-label', `Diminuer ${name}`);
    minus.textContent = '−';
    minus.disabled = true;

    const value = createEl('span');
    value.className = 'quantity-value';
    value.textContent = quantity;

    const plus = createEl('button');
    plus.className = 'quantity-button';
    plus.type = 'button';
    plus.setAttribute('aria-label', `Augmenter ${name}`);
    plus.textContent = '+';
    plus.disabled = true;

    control.append(minus, value, plus);

    const lineTotal = createEl('span');
    lineTotal.className = 'line-total';
    lineTotal.textContent = total;

    bottom.append(control, lineTotal);

    li.append(top, bottom);
    return li;
}

// CADRE ORANGE : le total + la note
const CartTotal = (total) => {
    const div = createEl('div');

    const p = createEl('p');
    p.className = 'cart-total';
    const label = createEl('span');
    label.textContent = 'Total';
    const amount = createEl('span');
    amount.textContent = total;
    p.append(label, amount);

    const note = createEl('p');
    note.className = 'cart-note';
    note.textContent = 'Prix fictifs pour l’exercice.';

    div.append(p, note);
    return div;
}

// CADRE VERT : tout le panier
// Il utilise CartItem et CartTotal
const Cart = (articles, total) => {
    const aside = createEl('aside');
    aside.className = 'cart';
    aside.setAttribute('aria-labelledby', 'cart-title');

    // Titre du panier + nombre d'articles
    const heading = createEl('div');
    heading.className = 'cart-heading';
    const h2 = createEl('h2');
    h2.id = 'cart-title';
    h2.textContent = 'Mon panier';
    const count = createEl('span');
    count.className = 'cart-count';
    count.textContent = `${articles.length} articles`;
    heading.append(h2, count);

    // La liste des articles
    const ul = createEl('ul');
    ul.className = 'cart-list';
    articles.forEach(article => {
        ul.appendChild(CartItem(article.name, article.quantity, article.total));
    });

    aside.append(heading, ul, CartTotal(total));
    return aside;
}

// Le pied de page
const Footer = (text) => {
    const footer = createEl('footer');
    footer.className = 'site-footer';
    footer.textContent = text;
    return footer;
}


/* ============================================================
   LES DONNÉES (les produits et le panier)
   ============================================================ */

const produits = [
    { category: 'Cahiers',  name: 'Cahier grand format', price: '1 200 FCFA', coverTitle: 'NOTES',  coverInfo: '180 pages' },
    { category: 'Écriture', name: 'Lot de 4 stylos',     price: '600 FCFA',   coverTitle: 'STYLOS', coverInfo: '4 couleurs' },
    { category: 'Cahiers',  name: 'Carnet de poche',     price: '800 FCFA',   coverTitle: 'IDÉES',  coverInfo: 'Format A6' },
    { category: 'Écriture', name: 'Lot de 3 surligneurs', price: '900 FCFA',  coverTitle: 'FLUO',   coverInfo: '3 couleurs' }
];

const articlesPanier = [
    { name: 'Cahier grand format', quantity: 1, total: '1 200 FCFA' },
    { name: 'Lot de 4 stylos',     quantity: 1, total: '600 FCFA' }
];


/* ============================================================
   ASSEMBLAGE DE LA PAGE
   ============================================================ */

// <main> qui contient le catalogue et le panier
const main = createEl('main');
main.className = 'shop-layout';

// <section> du catalogue (colonne de gauche)
const section = createEl('section');
section.className = 'catalog';
section.setAttribute('aria-labelledby', 'catalog-title');

// Les boutons de catégories
const div = createEl('div');
div.className = 'category-filters';
div.setAttribute('role', 'group');
div.setAttribute('aria-label', 'Catégories de produits');
div.append(Btn('Tous'), Btn('Cahier'), Btn('Stylo'));

// On remplit le catalogue
section.append(
    Title('Prêt pour les cours.', 'Quelques essentiels, un panier tout simple.'),
    Input('text', 'Recherche un article'),
    div,
    ResultCount(produits.length),
    ProductGrid(produits)
);

// On met le catalogue (gauche) et le panier (droite) dans <main>
main.append(section, Cart(articlesPanier, '1 800 FCFA'));

// Enfin, on ajoute tout dans le <body>
body.appendChild(Header(APP_NAME, 'Les essentiels de la rentrée', 'P.'));
body.append(main);
body.append(Footer('Maquette HTML/CSS · Les boutons sont désactivés : ils seront activés en JavaScript.'));
